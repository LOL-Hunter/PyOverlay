import os, time as t
import sys
from traceback import format_exc
from importlib import import_module, reload
from pysettings.text import MsgText, TextColor
from pysettings import tk
from PyOverlay.src.constants import STYLE_GROUP as SG


RUNNING_AS_COMPILED = False
if getattr(sys, 'frozen', False):  # Running as compiled
    RUNNING_AS_COMPILED = True
    BASE_PATH = os.path.join(os.path.expanduser("~"), "Documents", "PyOverlayPlugins") #C:\Users\langh\AppData\Local\Programs\Python\Python310\Lib\PyOverlay\src
    if not os.path.exists(BASE_PATH):
        os.mkdir(BASE_PATH)
    if not os.path.exists(os.path.join(BASE_PATH, "plugins")):
        os.mkdir(os.path.join(BASE_PATH, "plugins"))
    os.chdir(os.path.join(BASE_PATH, "plugins"))

else:
    BASE_PATH = os.getcwd()


class PluginData:
    def __init__(self, name, version, desc, path, module, plugin, priority, state="active", console=""):
        self.data = {
        "name":name,       # name of the Plugin
        "version":version,
        "description":desc,
        "path":path,
        "module":module,   # module instance from import
        "plugin":plugin,   # plugin instance from class: 
        "priority":priority,
        "state":state,  # active, inactive, disabled, error
        "console":console,
    }
    def __getitem__(self, key):
        return self.data[key]
    def __setitem__(self, key, value):
        self.data[key] = value
    def __lt__(self, other):
        return self["priority"] < other["priority"]
    def getRealPath(self):
        return os.path.join(os.path.split(os.path.split(BASE_PATH)[0])[0], *self["path"].split("."))+".py"
class PluginManager:
    PLUGIN_DATA:[PluginData] = [] # in correct priority order!
    PLUGIN_DATA_DICT = {}         # to fast access from name
    WINDOW = None
    @staticmethod
    def _getState(name):
        return PluginManager.PLUGIN_DATA_DICT[name]["state"]
    @staticmethod
    def call(eventName, **kwargs):
        """

        @param eventName:
        @param kwargs:
        @return: False -> no cancel, True one or more cancels!
        """
        canc = []
        event = None
        for data in PluginManager.PLUGIN_DATA:
            if event is not None and event["cancelOther"]: break
            if not data["state"] == "active": continue
            try:
                event = data["plugin"]._call(eventName, **kwargs)
            except Exception as e:
                exc = format_exc()
                data["console"] += "\n"+exc
                TextColor.print(exc, "red")
                tk.SimpleDialog.askError(PluginManager.WINDOW, f"An error occurred while executing event '<{eventName}>' in Plugin '{data['name']}'.\nCheck the console in the PluginManager for more information.", "PluginManager gui")
                data["state"] = "error"
            if event is not None: canc.append(event["setCanceled"])
        return any(canc)
    @staticmethod
    def _getPlugins(path):
        for pluginName in os.listdir(path):
            if os.path.splitext(pluginName)[1] != ".py": continue
            pluginName = pluginName.replace(".py", "")
            if pluginName.startswith("__"): continue
            yield pluginName
    @staticmethod
    def _loadPluginFromName(pluginName):
        try:
            module = import_module("PyOverlay.src.plugins." + pluginName
                                   if not RUNNING_AS_COMPILED else
                                   pluginName)
            if hasattr(module, "Plugin") and module.Plugin._INSTANCE is not None:

                instance = module.Plugin._INSTANCE
                pl_data = PluginData(
                    name=pluginName,
                    version=module.VERSION if hasattr(module, "VERSION") else None,
                    desc=module.DESCRIPTION if hasattr(module, "DESCRIPTION") else "Has no Description!",
                    path="PyOverlay.src.plugins." + pluginName,
                    module=module,
                    plugin=instance,
                    priority=instance.priority,
                    state="disabled" if instance._disabled else "active",
                )
                PluginManager.PLUGIN_DATA.append(pl_data)
                PluginManager.PLUGIN_DATA_DICT[pluginName] = pl_data
                instance._pluginName = pluginName
                instance._getStateHook = PluginManager._getState
                instance._window = PluginManager.WINDOW
                if instance._disabledInDev and PluginManager.WINDOW.devMode:
                    pl_data["state"] = "disabled"
                #t.sleep(0.2)
                state = PluginManager.PLUGIN_DATA[-1]["state"]
                nameLen = len(module.__name__)
                if state == "active":
                    instance._run()  # run the Plugin
                    TextColor.printStrf(
                        "§INFO   -Plugin successfully registered! (§c" + module.__name__ + "§g)" + "-" * (
                                    50 - nameLen + 2) + "§g-> §gENABLED")
                elif state == "disabled":
                    TextColor.printStrf(
                        "§INFO   -Plugin successfully registered! (§c" + module.__name__ + "§g)" + "-" * (
                                    50 - nameLen + 2) + "§g-> §rDISABLED")
                else:
                    TextColor.printStrf(
                        "§INFO   -Plugin successfully registered! (§c" + module.__name__ + "§g)" + "-" * (50 - nameLen))
            else:
                pl_data = PluginData(
                    name=pluginName,
                    version=None,
                    desc="",
                    path="PyOverlay.src.plugins." + pluginName,
                    module=None,
                    plugin=None,
                    priority=1000,
                    state="error",
                    console="Could not register Plugin: Plugin class not available!"
                )
                PluginManager.PLUGIN_DATA.append(pl_data)
                PluginManager.PLUGIN_DATA_DICT[pluginName] = pl_data
                TextColor.printStrf(
                    "§ERROR§rCould not register Plugin: Plugin class not available! (§c" + module.__name__ + "§r)")

        except Exception as e:
            exc = format_exc()
            pl_data = PluginData(
                name=pluginName,
                version=None,
                desc="",
                path="PyOverlay.src.plugins." + pluginName,
                module=None,
                plugin=None,
                priority=1000,
                state="error",
                console=str(exc)
            )
            PluginManager.PLUGIN_DATA.append(pl_data)
            PluginManager.PLUGIN_DATA_DICT[pluginName] = pl_data
            TextColor.printStrf("§r" + exc)
            TextColor.printStrf("§ERRORCould not execute Plugin! (§c" + pluginName + "§r)")
            tk.SimpleDialog.askError(PluginManager.WINDOW, exc, "Plugin-Loader-Exception")
    @staticmethod
    def loadPlugins(loadingFrame):
        pluginNames = [i for i in PluginManager._getPlugins(os.path.join(BASE_PATH, "plugins"))]
        """
        master = tk.Dialog(window)
        master.setTopmost(True)
        master.setTitle("Plugin loader")
        master.setCloseable(False)
        master.setWindowSize(350, 100)
        """
        pg = tk.Progressbar(loadingFrame)
        pg.placeRelative(fixHeight=30, changeX=+15, changeWidth=-30, stickDown=True, changeY=-75)
        lb = tk.Label(loadingFrame, SG).setText(f"Loading Plugins... (0/{len(pluginNames)}) 0%").setFont(15)
        lb.placeRelative(fixHeight=25, changeX=+15, changeWidth=-30, stickDown=True, changeY=-175)
        lb2 = tk.Label(loadingFrame, SG).setText("-textEditorPlugin").setFont(15)
        lb2.placeRelative(fixHeight=25, changeX=+15, changeWidth=-30, stickDown=True, changeY=-125)
        MsgText.info(f"Loading plugins... ({len(pluginNames)})")
        for i, pluginName in enumerate(pluginNames):
            PluginManager._loadPluginFromName(pluginName)
            lb.setText(f"Loading Plugins... ({i}/{len(pluginNames)}) {round((i / len(pluginNames)) * 100, 1)}%")
            lb2.setText(f"Plugin: {pluginName}")
            pg.setPercentage((i / len(pluginNames)) * 100)
            PluginManager.WINDOW.update()
        pg.setPercentage(100)
        lb.setText(f"Finishing up... 100%")
        lb2.setText("Building gui...")
        #t.sleep(.5)


        PluginManager.PLUGIN_DATA.sort()
        PluginManager.PLUGIN_DATA.reverse()
