from PyOverlay.src.gui import Overlay
from psutil import cpu_percent, virtual_memory
from pyautogui import position, locateAllOnScreen



#Overlay(name="cpu_count4", command=lambda :"CPU: " + str(cpu_percent()) + "%")
#Overlay(name="cpu_count5", command=lambda :"CPU: " + str(cpu_percent()) + "%")



