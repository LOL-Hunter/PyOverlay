from PyOverlay.src.plugins import Plugin, EventHandler
from pysettings.jsonConfig import JsonConfig
from pysettings import tk
from requests import get as getReq
import os

VERSION_MANIFEST_URL = r"https://launchermeta.mojang.com/mc/game/version_manifest.json"
MINECRAFT_VERSIONS_FOLDER = os.path.join(os.getenv('APPDATA'), ".minecraft", "versions")


class MinecraftVersionTest(EventHandler):
    def onEnable(self):
        versionsFound = []
        #get versions from mojang
        raw_data = getReq(url=VERSION_MANIFEST_URL).text
        data = JsonConfig.fromString(raw_data)
        versions = data["versions"]
        #parse and save (version:time)
        versionTimeDict = {}
        for versionData in versions:
            version = versionData["id"]
            time = versionData["releaseTime"]
            versionTimeDict[version] = time
        # Minecraft Folder analysis
        for versionFolder in os.listdir(MINECRAFT_VERSIONS_FOLDER):
            versionFolderConfigPath = os.path.join(MINECRAFT_VERSIONS_FOLDER, versionFolder, versionFolder+".json")
            if not os.path.exists(versionFolderConfigPath):
                # ex. Optifine does not have a version json file
                # -> ignore that!
                continue
            versionConfig = JsonConfig.loadConfig(versionFolderConfigPath)
            version = versionConfig["id"]
            time = versionConfig["releaseTime"]
            if version not in versionTimeDict.keys():
                # ignore versions not in Manifest
                continue
            # check if versions are different
            #print(version, time, versionTimeDict[version])
            if versionTimeDict[version] != time:
                versionsFound.append(f"Found Update {version}")
        # look if a newer version & snapshot of minecraft released (not yet in versions folder)
        latestVersion = data["latest"]["release"]
        if latestVersion not in os.listdir(MINECRAFT_VERSIONS_FOLDER):
            versionsFound.append(f"Found new Version: {latestVersion}")
        latestSnapshot = data["latest"]["snapshot"]
        if latestSnapshot not in os.listdir(MINECRAFT_VERSIONS_FOLDER):
            versionsFound.append(f"Found new Snapshot: {latestVersion}")
        # open Info if updates are found
        if len(versionsFound) > 0:
            tk.SimpleDialog.askInfo(
                plugin.getWindow(),
                title="Minecraft Version Test",
                message="\n".join(versionsFound)
            )


plugin = Plugin(priority=0)
plugin.register(MinecraftVersionTest)
plugin.disableInDevMode() # This Plugin is disabled in DevMode! To minimize network traffic while testing 1.000 times :)