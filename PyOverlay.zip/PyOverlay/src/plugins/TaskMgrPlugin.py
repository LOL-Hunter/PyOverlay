from PyOverlay.src.plugins import Plugin, EventHandler
from PyOverlay.src.constants import STYLE_GROUP as SG
from pysettings import tk
from psutil import process_iter

"""
TODO:
[] include System Processes


"""


def isSystemProc(proc):
    name = proc.name()
    if not name.endswith(".exe"): return True
    try:
        cwd = proc.cwd()
        if cwd.lower().startswith(r"c:\windows"): return True
        return False
    except Exception as e:
        return True


class Process:
    def __init__(self):
        self._data = {
            "name":"",
            "pid":"",
            "process":None,
            "cwd":""
        }
    def __setitem__(self, key, value):
        self._data[key] = value

    def __getitem__(self, item):
        return self._data[item]

class ConnectionViewGui(tk.Dialog):
    def __init__(self, master, process):
        super().__init__(master, SG, False)
        name = process["name"]
        self.process:Process = process
        self.setTitle(f"ConnectionView ({name})")
        self.setPositionOnScreen(300, 300)
        self.setWindowSize(300, 200)
        self.lift()

        self.refreshImg = tk.PILImage.loadImage(r".\images\icons\refresh.png")
        self.refreshImg.resizeToIcon()
        self.refreshImg.preRender()

        self.toolBar = tk.LabelFrame(self, SG)
        self.toolBar.setText("ToolBar")
        tk.Button(self.toolBar, SG).place(0, 0, 30, 30).setCommand(self.refresh).setImage(self.refreshImg).attachToolTip("Refresh")

        self.toolBar.placeRelative(fixHeight=50)



        self.show()

    def refresh(self):
        for connection in self.process["process"].connections("all"):
            print(connection)






class TaskMgrGui(tk.Dialog):
    INCLUDE_SYSTEM_PROCESSES = False
    def __init__(self):
        super().__init__(plugin.getWindow(), SG, False)
        self.processList = {}
        self.selectedProcess = None


        self.setWindowSize(800, 500)
        self.setTitle("PyTaskManager")
        self.setPositionOnScreen(300, 300)

        self.refreshImg = tk.PILImage.loadImage(r".\images\icons\refresh.png")
        self.refreshImg.resizeToIcon()
        self.refreshImg.preRender()

        self.toolBar = tk.LabelFrame(self, SG)
        self.toolBar.setText("ToolBar")
        tk.Button(self.toolBar, SG).place(0, 0, 30, 30).setCommand(self.refresh).setImage(self.refreshImg).attachToolTip("Refresh")

        self.toolBar.placeRelative(fixHeight=50)

        self.processFrame = tk.LabelFrame(self, SG)
        self.processFrame.setText("All available processes:")

        self.processTreeView = tk.TreeView(self.processFrame)
        self.processTreeView.setTableHeaders("Name", "Current Working Directory", "CPU", "Memory", "PID")
        self.processTreeView.onSingleSelectEvent(self.onTreeSelect)

        self.tvContext = tk.ContextMenu(self.processTreeView, SG)
        tk.Button(self.tvContext).setText("View connections").setCommand(self.listenTo)


        self.tvContext.create()




        self.processTreeView.placeRelative(changeWidth=-5, changeHeight=-20)



        self.processFrame.placeRelative(fixY=50)







        self.show()
        self.updateDynamicWidgets()

    def onTreeSelect(self, e):
        sel = self.processTreeView.getSelectedItems()
        if sel is None: return
        sel = sel[0]
        self.selectedProcess = sel


    def listenTo(self):
        if self.selectedProcess is None: return
        process = self.processList[self.selectedProcess["PID"]]
        ConnectionViewGui(self, process)



    def refresh(self):
        self.processTreeView.clear()
        self.selectedProcess = None
        self.processList = {}
        for proc in process_iter():

            name = proc.name()
            if not isSystemProc(proc):
                process = Process()
                process["name"] = name
                process["pid"] = proc.pid
                process["process"] = proc
                process["cwd"] = proc.cwd()
                self.processList[process["pid"]] = process
                cpu = proc.cpu_percent()
                mem = proc.memory_percent()
                if mem < .01:
                    mem = "<0.01%"
                else:
                    mem = str(round(mem, 2))+"%"

                self.processTreeView.addEntry(name, process["cwd"], cpu, mem, process["pid"])
                self.processTreeView.update()


class TaskMgrPlugin(EventHandler):
    OPEN_GUI = None
    def onEnable(self):
        return
        self.onOpenGUI()


    def onOpenGUI(self):
        if TaskMgrPlugin.OPEN_GUI is not None: TaskMgrPlugin.OPEN_GUI.destroy()
        TaskMgrPlugin.OPEN_GUI = TaskMgrGui()






plugin = Plugin()
plugin.register(TaskMgrPlugin)
plugin.disable()