from pysettings import tk
from PyOverlay.src.constants import STYLE_GROUP as SG, Color


class AutomationConfigurationGUI(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.onCloseEvent(self.onClose)
        self.hide()

        self.setTitle("")
        self.createGUI()

    def createGUI(self):
        pass













    def onClose(self, e:tk.Event):
        e.setCanceled(True)
        self.hide()









class Automation:
    def __init__(self, window, master):

        self.configurationGUI = AutomationConfigurationGUI(window)
        self.isRunning = False
        self.runningJob = None

        self.lf_available_jobs = tk.LabelFrame(master, SG)
        self.lf_available_jobs.setText("Available Macros")

        self.availableJobs = tk.Listbox(self.lf_available_jobs, SG)
        self.availableJobs._get()["activestyle"] = "none" # remove underline on select
        self.availableJobs.setSelectForeGroundColor(tk.Color.WHITE)
        self.availableJobs.setSelectBackGroundColor(Color.COLOR_GRAY)
        self.availableJobs.add("test")

        self.availableJobs.placeRelative(changeHeight=-20, changeWidth=-5)
        self.lf_available_jobs.placeRelative(xOffsetRight=50)

        self.lf_currentJob = tk.LabelFrame(master, SG)
        self.lf_currentJob.setText("No Job Selected!")

        self.currentJobList = tk.Listbox(self.lf_currentJob, SG)
        self.currentJobList._get()["activestyle"] = "none"  # remove underline on select
        self.currentJobList.setSelectForeGroundColor(tk.Color.WHITE)
        self.currentJobList.setSelectBackGroundColor(Color.COLOR_GRAY)

        self.currentJobList.placeRelative(changeHeight=-20, changeWidth=-5)


        self.lf_currentJob.placeRelative(xOffsetLeft=50, changeHeight=-50)




        tk.Button(master, SG).setText("Edit Scripts...").placeRelative(xOffsetLeft=50, fixHeight=25, stickDown=True, changeY=-25).setCommand(self.configurationGUI.show)
        self.btn_run = tk.Button(master, SG).setText("Run Script...").placeRelative(xOffsetLeft=50, fixHeight=25, stickDown=True).setCommand(self.runScript)


    def runScript(self, e):
        if self.isRunning:
            self.isRunning = False
            # cancel Job
            self.btn_run.setBg(Color.COLOR_DARK)
            self.btn_run.setStyle(tk.Style.RAISED)
            return

        sel = self.availableJobs.getSelectedItem()
        if sel is not None:
            self.runningJob = self.getJobFromID(sel)
            self.isRunning = True
            self.btn_run.setStyle(tk.Style.SUNKEN)
            self.btn_run.setBg("green")




    def getJobFromID(self, _id):
        return ""

    def updateList(self):




        self.availableJobs.setSlotBgAll(Color.COLOR_DARK)

