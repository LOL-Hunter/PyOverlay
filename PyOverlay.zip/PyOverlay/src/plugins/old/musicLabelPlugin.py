from PyOverlay.src.plugins import EventHandler, Event, Plugin
import asyncio
import pysettings.tk as tk
from PIL import Image
import io, time as t
from winsdk.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as MediaManager
from winsdk.windows.storage.streams import DataReader, Buffer, InputStreamOptions
from PyOverlay.src.gui import Overlay

VERSION = "v1.0"
DESCRIPTION = """View your current Song as Overly!"""
POS = [1636, 6]

async def get_media_info():
    sessions = await MediaManager.request_async()

    current_session = sessions.get_current_session()
    if current_session:
        if current_session.source_app_user_model_id == "Spotify.exe":
            info = await current_session.try_get_media_properties_async()
            info_dict = {song_attr: info.__getattribute__(song_attr) for song_attr in dir(info) if song_attr[0] != '_'}
            info_dict['genres'] = list(info_dict['genres'])
            return info_dict
    else:
        print("There is no media session!")


async def read_stream_into_buffer(stream_ref, buffer):
    readable_stream = await stream_ref.open_read_async()
    readable_stream.read_async(buffer, buffer.capacity, InputStreamOptions.READ_AHEAD)

def get_img(_data):
    thumb_stream_ref = _data['thumbnail']

    # 5MB (5 million byte) buffer - thumbnail unlikely to be larger
    thumb_read_buffer = Buffer(5000000)

    # copies data from data stream reference into buffer created above
    asyncio.run(read_stream_into_buffer(thumb_stream_ref, thumb_read_buffer))

    # reads data (as bytes) from buffer
    buffer_reader = DataReader.from_buffer(thumb_read_buffer)
    byte_buffer = buffer_reader.read_buffer(thumb_read_buffer.length)

    return Image.open(io.BytesIO(bytearray(byte_buffer)))





#{'album_artist': 'TheFatRat',
# 'album_title': 'Time Lapse',
# 'album_track_count': 0,
# 'artist': 'TheFatRat',
# 'genres': [],
# 'playback_type': <MediaPlaybackType.MUSIC: 1>,
# 'subtitle': '',
# 'thumbnail': <_winsdk_Windows_Storage_Streams.IRandomAccessStreamReference object at 0x00000128C22D76F0>,
# 'title': 'Time Lapse',
# 'track_number': 1}


class MusicOverlay(Overlay):
    def __init__(self, master):
        self.lastTitle = ""
        self.timer = t.time()
        super().__init__(
            master=master,
            name="musicLabel",
            x=300,
            y=130,
            command=self._run
        )
        self.imgLabel = tk.Label(self)
        self._info.placeForget()
        self._info.setFont(10)
        self.setPositionOnScreen(*POS)
    def _run(self):
        if t.time() - self.timer > 2:
            self.timer = t.time()
            data = asyncio.run(get_media_info())
            if data["artist"]+"\n"+data["title"] == self.lastTitle:
                return self.lastTitle
            self.lastTitle = data["artist"]+"\n"+data["title"]
            img = get_img(data)
            width, height = img.size
            tkimg = tk.PILImage(img)
            tkimg.resizeTo(128, 128)
            self.imgLabel.setImage(tkimg)
            self.imgLabel.setBg("blue")
            self.imgLabel.place(x=0, y=0, width=128, height=128)
            self._info.place(128, 0, height=128, width=150)
            return data["artist"]+"\n"+data["title"]
        return self.lastTitle

class MusicPlayerPlugin(EventHandler):
    def onEnable(self):
        print("enable")





plugin = Plugin(priority=0)
plugin.registerOverlay(MusicOverlay)
plugin.register(MusicPlayerPlugin)
plugin.disable()

