from PyOverlay.src.plugins import Plugin, EventHandler
from PyOverlay.src.constants import STYLE_GROUP as SG, Color
from pysettings import tk, iterDict
from pyperclip import copy
import os
from threading import Thread
class OneClickSelector(tk.ContextMenu):
    def __init__(self, optionList:list, loc=tk.Location2D(350, 275)):
        super().__init__(plugin.getWindow(), SG, eventType=None)
        self.loc = loc
        self.cmd = None
        for option in optionList:
            tk.Button(self).setText(option).setCommand(tk.Cmd(self._selectOption, option))
        self.create()

    def _selectOption(self, opt):
        if self.cmd is None: return
        self.cmd(opt)

    def openSelector(self, cmd):
        self.open(self.loc)
        self.cmd = cmd
class Tool:
    NAME = ""
    def __init__(self, plugin):
        pass
    def onCreateGUI(self):
        pass
    def onSelect(self):
        pass

class T_JavaPathFinder(Tool):
    NAME = "Java Path Finder"
    def onSelect(self):
        def onSelect(opt):
            copy(opt)
        def parse(path):
            return [os.path.join(path, i, "bin") for i in os.listdir(path)]
        paths = []
        if os.path.exists(os.path.join("C:\Program Files", "Java")):
            paths += parse(os.path.join("C:\Program Files", "Java"))
        if os.path.exists(os.path.join("C:\Program Files (x86)", "Java")):
            paths += parse(os.path.join("C:\Program Files (x86)", "Java"))
        onc = OneClickSelector(paths)
        onc.openSelector(onSelect)
class T_StackCalculator(Tool):
    NAME = "Stack Calculator"
    def onSelect(self):
        num = tk.SimpleDialog.askInteger(plugin.getWindow(), "Amount?", "Stack Calc")
        if num is None: return
        stacks = int(num/64)
        items = num % 64
        tk.SimpleDialog.askInfo(plugin.getWindow(), f"Result: [{stacks}|{items}]")
class T_JavaDevompiler(Tool):
    NAME = "Java Decompiler"
    def onSelect(self):
        pass
class T_OpenTskMgr(Tool):
    NAME = "Open PyTaskMgr"
    def onSelect(self):
        #plugin.call()
        pass


class ToolPlugin(EventHandler):
    def onEnable(self):
        self.tools = {} # name:class Tool instances
        tools_class_names = self.parseTools()
        
        self.lf_available_tools = tk.LabelFrame(self.master, SG)
        self.lf_available_tools.setText(f"Available Tools [{len(tools_class_names)}]")

        self.availableTools = tk.Listbox(self.lf_available_tools, SG)
        self.availableTools.bind(self.onToolSelect, tk.EventType.DOUBBLE_LEFT)
        self.availableTools.bind(self.onToolSelect, tk.EventType.RETURN)
        self.availableTools.bindArrowKeys()
        self.availableTools._get()["activestyle"] = "none"  # remove underline on select
        self.availableTools.setSelectForeGroundColor(tk.Color.WHITE)
        self.availableTools.setSelectBackGroundColor(Color.COLOR_GRAY)

        for tool in tools_class_names:
            _class = globals()[tool]
            self.tools[_class.NAME.replace(" ", "_")] = _class(self)
            self.availableTools.add(_class.NAME)

        self.availableTools.placeRelative(changeHeight=-20-25, changeWidth=-5, changeY=25)
        self.search_E = tk.Entry(self.lf_available_tools, SG)
        self.search_E.onUserInputEvent(self.onSearch)
        self.search_E.bind(self.onSearchRightClick, tk.EventType.RIGHT_CLICK)
        self.search_E.bind(self.onSearchRightClick, tk.EventType.ESC)
        self.search_E.placeRelative(fixHeight=25, changeWidth=-5)
        self.search_E.bind(self.arrowKeysEntry, tk.EventType.ARROW_UP, args=["up"])
        self.search_E.bind(self.arrowKeysEntry, tk.EventType.ARROW_DOWN, args=["down"])

        self.lf_available_tools.placeRelative(xOffsetRight=50)

    def onSearch(self, e):
        con = self.search_E.getText().lower()
        self.availableTools.clear()
        for tool_name, class_ in iterDict(self.tools):
            tool = tool_name.lower()
            if con in tool or con == "":
                self.availableTools.add(class_.NAME)
    def onSearchRightClick(self, e):
        self.search_E.clear()
        self.onSearch("")
    def onToolSelect(self, e):
        sel = self.availableTools.getSelectedItem()
        if sel is None: return
        sel = sel.replace(" ", "_")
        _class = self.tools[sel]
        _class.onSelect()
    def onTabRegisterEvent(self):
        self.master = plugin.registerTab("Tools")
    def parseTools(self):
        return [i for i in CLASSES if i.startswith("T_")]
    def arrowKeysEntry(self, e):
        pass

CLASSES = dir()
plugin = Plugin(priority=0)
plugin.register(ToolPlugin)