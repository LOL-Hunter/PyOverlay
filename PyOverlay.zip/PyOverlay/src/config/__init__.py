from pysettings.jsonConfig import AdvancedJsonConfig
import os

PATH = os.path.dirname(os.path.abspath(__file__))


class Config:
    AdvancedJsonConfig.setConfigFolderPath(PATH)

